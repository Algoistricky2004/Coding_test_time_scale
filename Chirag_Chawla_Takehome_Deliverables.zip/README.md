# AI Research Engineer take-home: deliverables
**Author: CHIRAG CHAWLA**

**Question:** can a small open coding model (Qwen3.5-9B on one Google Colab L4 GPU) solve more programming problems if we change how it spends effort while answering (more tries, fixing its own mistakes, stopping early), with no training?
**Short answer:** our main idea (stop spending on a problem once the model starts rambling) was NOT confirmed (+2.6 points; we required +3). Checking answers with the sample tests and letting the model fix failed code did help. Read `4_research_memo/Chirag_Chawla_Research_Memo_FULL.pdf` first: pages 1-3 are the memo (the assignment's 3-page limit), pages 4-9 are an appendix that explains the setup, every method and every number in plain language. `Chirag_Chawla_Research_Memo_3_pages_only.pdf` is just the 3-page memo.

Agent/coding-assistant session transcripts are NOT included (excluded on request). Paid API spend: $0 of the $100 allowed. The notebook has an optional paid-API part, but because of the budget (only $5 of API credit) all tests used the open model on the Colab L4 GPU.

## What is in this zip

| Folder / file | What it is |
|---|---|
| `4_research_memo/Chirag_Chawla_Research_Memo_FULL.pdf` | The memo (pages 1-3) plus a plain-language appendix (pages 4-9: setup, why 38 problems and not 50, how the 858 attempts add up, each method, the 129 strategies, glossary, all 12 tests) |
| `4_research_memo/Chirag_Chawla_Research_Memo_3_pages_only.pdf` | Only the 3-page memo, for the assignment's page limit |
| `3_pareto_plots/pareto_plot_success_vs_tokens.png` | **Pareto plot**: share of problems solved vs cost (tokens per problem), 10 highlighted strategies + frontier |
| `3_pareto_plots/pareto_plot_success_vs_time.png` | Same, against waiting time per problem |
| `3_pareto_plots/*_original.png` | The notebook's own plots with all 129 strategies (dense) |
| `2_results/per_problem_results.csv` | **Per-task outcomes**: for each of the 38 problems and each method: attempts, how many passed all hidden tests, average tokens, model calls, latency |
| `2_results/per_attempt_results.csv` | **All 858 attempts**: output tokens, input tokens read, model calls, answer rounds, latency, test-running CPU time, example-test and hidden-test outcome |
| `2_results/strategies_success_vs_cost.csv` | **129 strategies**: success rate, 95% range, tokens per problem, estimated L4 GPU-minutes, modeled seconds |
| `2_results/problems_list.csv` | The 38 problems used (id, title, contest, date, difficulty label, number of tests) |
| `2_results/hypothesis_status.json`, `auto_generated_full_report.md` | The notebook's own full report: all 12 pre-written tests and every analysis |
| `2_results/frontier_membership.csv`, `signal_quality.csv`, `routing_groups.csv`, `throughput.json` | Supporting analyses and the measured generation speed |
| `2_results/test_cases/problems_with_tests.json.gz` | **The test cases**: for each of the 38 problems the statement, the 1-4 example tests (106 in all) and the 30 hidden tests used for scoring (1,140 in all), as input and expected output. Taken from the public LiveCodeBench collection |
| `2_results/verify_results.py` | Re-runs the saved programs on the saved hidden tests and compares with the recorded verdicts (see below) |
| `2_results/model_transcripts/` | Every model conversation (`transcripts.jsonl`) and the raw attempt records (`pool.jsonl`) |
| `1_code/itc_qwen_l4_FINAL_v5.ipynb` | **Implementation**: one Colab notebook, 7 code cells |

## Data
LiveCodeBench ("code_generation_lite" on Hugging Face): AtCoder contest problems with official tests. We used 38 problems from contests held 2025-01-11 to 2025-04-06 (26 from Beginner contests, 12 from Regular contests; 33 labelled hard, 5 medium). Selected at random (seed 1) among stdin/stdout problems with at least 10 tests and one large test input, excluding 24 problems used earlier to form the hypothesis. The model sees only the problem text and the 1-4 sample tests; answers are scored on 30 hidden official tests (6 s each). A problem is solved only if all 30 pass. The test cases are included (see the next section) so the results can be re-checked.

## How to reproduce (about 3 hours on a Colab L4)
1. Open Google Colab, upload `1_code/itc_qwen_l4_FINAL_v5.ipynb`, and choose **Runtime > Change runtime type > L4 GPU**. Leave the API key blank (everything is local; set `MOUNT_DRIVE = True` in Cell 1 to keep results on Google Drive).
2. Smoke test first: keep `PROFILE = "smoke"` in Cell 1 and run Cells 1-7 (about 15-20 minutes). It runs every method once on 3 problems to check the setup.
3. Real run: set `PROFILE = "final"` (SEED = 1 is already set) and run Cells 1-7 again. Our run generated 2.08 million tokens in 156 minutes of generation, plus setup and test running. It is resumable: after a disconnect, re-run Cells 1-3.
4. Cell 5 and Cell 6 print every analysis and the status of the 12 pre-written tests; Cell 7 writes the results files and downloads a zip like the one in `2_results`.
5. Expect small differences: attempts are sampled with temperature, so numbers move a little between runs (about +-2.5 points from attempt noise versus about +-9 points from which problems are used), and the dataset snapshot may change.

## Definitions
- **Token**: a word-piece the model writes (1,000 tokens is about 750 words; about 4.5 seconds of L4 time when many attempts run together, 223 tokens/s measured).
- **Sample tests / hidden tests**: the 1-4 examples printed in the problem (the model may run them) vs. 30 secret official tests used only for scoring.
- **Fix**: after a failed sample test, the model sees the failure and rewrites the code (up to 2 times).
- **Cost** is tokens generated (and the GPU time they take); calls, latency and CPU test time are logged for every attempt.

## How the results are backed by test cases, and how to re-check them
- Every "solved" number comes from running the model's final program on the 30 hidden tests of its problem; a problem is solved only if all 30 pass. Strategies that use the example tests (keep an attempt that passes them, fix after a failed one) use the 1-4 example tests the model is allowed to see. Both kinds of tests are in `test_cases/problems_with_tests.json.gz`.
- `per_attempt_results.csv` has, for each of the 858 attempts: `passed_example_tests_first_try`, `passed_example_tests_final`, `passed_all_30_hidden_tests` and `hidden_test_outcome` (ok / wrong answer / runtime error / too slow / no code).
- `model_transcripts/pool.jsonl` stores the final program of every attempt that wrote one (780 of 858; the other 78 never produced code and count as failed).
- To re-check: `cd 2_results && python verify_results.py --sample 60` re-runs a random sample of saved programs on the saved hidden tests (6 s per test, Linux) and prints how many verdicts are identical to the recorded ones; `--all` checks every program (about an hour on one CPU). We ran two random samples ourselves (24 and 44 programs): all 68 verdicts were identical to the recorded ones. A difference could only come from timing on a very slow machine.
