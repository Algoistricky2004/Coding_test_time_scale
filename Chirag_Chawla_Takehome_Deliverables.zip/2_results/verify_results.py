#!/usr/bin/env python3
"""Re-check saved results by RE-RUNNING the model's saved programs on the saved test cases.
Usage:  python verify_results.py --sample 60        (random sample; quick)
        python verify_results.py --all              (all attempts that have a program; slow: about 1 hour on one CPU)
It runs each saved final program on the problem's 30 hidden tests (6 s per test, 3 GB memory, Linux), and compares
the verdict with the one recorded during the experiment (passed_all_30_hidden_tests in per_attempt_results.csv).
Differences can only come from timing (very large inputs on a slow or busy CPU)."""
import argparse, gzip, json, random, resource, subprocess, sys, tempfile, os
ap = argparse.ArgumentParser(); ap.add_argument("--sample", type=int, default=60); ap.add_argument("--all", action="store_true"); ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--tests", default="test_cases/problems_with_tests.json.gz"); ap.add_argument("--pool", default="model_transcripts/pool.jsonl"); a = ap.parse_args()
probs = {p["id"]: p for p in json.load(gzip.open(a.tests, "rt"))}
rows = [json.loads(l) for l in open(a.pool)]; rows = [r for r in rows if r.get("code")]
if not a.all:
    random.Random(a.seed).shuffle(rows); ok = [r for r in rows if r["hid_pass"]][: a.sample // 2]; bad = [r for r in rows if not r["hid_pass"]][: a.sample - len(ok)]; rows = ok + bad
def limits(): resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
def same(got, exp):
    def eq(x, y):
        if x == y: return True
        try: return ("." in y or "e" in y.lower()) and abs(float(x) - float(y)) <= 1e-6 * max(1.0, abs(float(y)))
        except ValueError: return False
    g = [l.split() for l in got.strip().splitlines()]; e = [l.split() for l in exp.strip().splitlines()]
    return len(g) == len(e) and all(len(u) == len(v) and all(eq(p, q) for p, q in zip(u, v)) for u, v in zip(g, e))
def passes_all(code, tests):
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as f: f.write(code); path = f.name
    try:
        for t in tests:
            try: p = subprocess.run([sys.executable, path], input=t["input"], capture_output=True, encoding="utf-8", errors="replace", timeout=6, preexec_fn=limits)
            except subprocess.TimeoutExpired: return False, "tle"
            if p.returncode != 0: return False, "runtime"
            if not same(p.stdout, t["output"]): return False, "wrong"
        return True, "ok"
    finally: os.unlink(path)
agree = 0; diffs = []
for i, r in enumerate(rows, 1):
    res, kind = passes_all(r["code"], probs[r["pid"]]["hidden"]); same_ = (res == bool(r["hid_pass"])); agree += same_
    if not same_: diffs.append((r["key"], "recorded", r["hid_pass"], r["hid_kind"], "now", res, kind))
    if i % 10 == 0: print(f"  checked {i}/{len(rows)}", flush=True)
print(f"\nre-run {len(rows)} saved programs on the hidden tests: verdict identical to the recorded one for {agree} ({100*agree/len(rows):.1f}%)")
for d in diffs: print("  DIFFERENT:", d)
