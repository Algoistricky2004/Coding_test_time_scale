# Auto-generated results summary

```
Problems N=38 | complete K per arm: {'nothink': 3, 'direct1200': 6, 'direct1200_fix2': 3, 'force1500': 2, 'nothink_fix2': 1} | partial (hard-only) arms: ['think3k', 'think8k', 'direct_many'] | speed: batched 223 tok/s, single-stream 16 tok/s
Infra errors logged (excluded from pools): 0
!! nothink: 46% of attempts were cut off before writing any code; they count as failures (cut-off attempts that already had code are scored normally).
!! nothink_fix2: 29% of attempts were cut off before writing any code; they count as failures (cut-off attempts that already had code are scored normally).

simulating strategies (random draws from the pool, 150 draws per problem) ...

======== PARETO FRONTIER (deployable strategies; x = est. GPU-min per problem) ========

strategy                                                      GPU-min  success   95% CI
direct1200 single                                               0.077    12.2%   [4.5%, 21.7%]
force1500 single                                                0.147    19.5%   [9.0%, 31.5%]
direct1200_fix2 single                                          0.207    23.8%   [11.5%, 37.0%]
force1500 verify-stop K<=2 w=1                                  0.268    26.3%   [13.2%, 42.1%]
nothink single                                                  0.293    28.1%   [16.4%, 42.2%]
nothink K=2 confwin                                             0.585    34.1%   [20.0%, 48.1%]
nothink K=2 conf                                                0.587    34.2%   [20.1%, 49.1%]
nothink_fix2 single                                             0.624    34.2%   [18.4%, 50.0%]
route[nothink->direct1200_fix2]                                 0.761    35.9%   [21.1%, 52.6%]
route[nothink->nothink_fix2]                                    0.786    36.1%   [20.3%, 51.2%]
nothink K=3 conf                                                0.879    36.8%   [23.7%, 52.6%]

======== PARETO FRONTIER (x = modeled latency, seconds) ========

strategy                                                      seconds  success   95% CI
direct1200 single                                              63.963    12.2%   [4.5%, 21.7%]
direct1200 K=2 short                                           68.370    16.3%   [6.9%, 26.2%]
direct1200 K=2 combo                                           68.390    16.4%   [6.8%, 27.3%]
direct1200 K=2 bf                                              68.475    16.6%   [7.0%, 27.7%]
direct1200 K=3 public                                          69.697    18.3%   [7.9%, 29.5%]
direct1200 K=3 combo                                           69.713    19.0%   [8.7%, 31.6%]
direct1200 K=4 bf                                              70.590    21.0%   [9.6%, 34.1%]
direct1200 K=5 confwin                                         71.056    21.7%   [9.8%, 34.3%]
direct1200 K=5 cluster                                         71.097    22.4%   [9.7%, 36.4%]
direct1200 K=6 conf                                            71.559    23.7%   [10.5%, 39.5%]
force1500 K=2 public                                          135.720    26.3%   [13.2%, 42.1%]
direct1200_fix2 K=2 public                                    186.967    27.3%   [14.9%, 42.1%]
direct1200_fix2 verify-stop+bf K<=3 w=3                       191.997    28.2%   [15.0%, 42.1%]
nothink K=2 public                                            282.163    33.6%   [19.9%, 47.3%]
nothink K=2 confwin                                           282.349    34.1%   [20.0%, 48.1%]
nothink K=2 conf                                              282.744    34.2%   [20.1%, 49.1%]
nothink K=3 conf                                              296.065    36.8%   [23.7%, 52.6%]

Dominated configurations: 104 of 115

======== T1  VERIFY-THEN-STOP: stop at the first attempt that passes the examples (vs always run all K) ========
  nothink       K=3 wave=1: tokens 10182 vs 11740 (+13%) | success 35.9% vs 35.8% (diff +0.001 [+0.000,+0.002]) | modeled latency 632s vs 296s
  nothink       K=3 wave=2: tokens 10907 vs 11740 (+7%) | success 36.0% vs 35.8% (diff +0.002 [+0.000,+0.007]) | modeled latency 473s vs 296s
  nothink       K=3 wave=3: tokens 11740 vs 11740 (+0%) | success 36.0% vs 35.8% (diff +0.001 [+0.000,+0.004]) | modeled latency 296s vs 296s
  direct1200    K=6 wave=1: tokens 5408 vs 6200 (+13%) | success 23.0% vs 23.0% (diff +0.000 [+0.000,+0.001]) | modeled latency 335s vs 72s
  direct1200    K=6 wave=2: tokens 5548 vs 6200 (+11%) | success 23.0% vs 23.0% (diff +0.000 [+0.000,+0.000]) | modeled latency 182s vs 72s
  direct1200    K=6 wave=3: tokens 5713 vs 6200 (+8%) | success 22.8% vs 23.0% (diff -0.002 [-0.007,+0.000]) | modeled latency 127s vs 72s
  direct1200_fix2 K=3 wave=1: tokens 7057 vs 8282 (+15%) | success 28.1% vs 28.2% (diff -0.001 [-0.002,+0.000]) | modeled latency 438s vs 192s
  direct1200_fix2 K=3 wave=2: tokens 7588 vs 8282 (+8%) | success 28.1% vs 28.2% (diff -0.001 [-0.003,+0.000]) | modeled latency 316s vs 192s
  direct1200_fix2 K=3 wave=3: tokens 8282 vs 8282 (+0%) | success 28.1% vs 28.2% (diff -0.001 [-0.002,+0.000]) | modeled latency 192s vs 192s
  force1500     K=2 wave=1: tokens 3582 vs 3947 (+9%) | success 26.3% vs 26.3% (diff +0.000 [+0.000,+0.000]) | modeled latency 222s vs 136s
  force1500     K=2 wave=2: tokens 3947 vs 3947 (+0%) | success 26.3% vs 26.3% (diff +0.000 [+0.000,+0.000]) | modeled latency 136s vs 136s
  rule: holds if the saving is >= 20% and success is not clearly worse; wave=1 is slowest (sequential), wave=3 ~ parallel.

======== T2  CONSISTENCY ROUTING: 'consistent and wrong' problems switch method instead of resampling ========
  route[nothink->nothink_fix2]: success 36.1% at 10498 tok | states: verified 42%, entrenched->switch 3%, unstable->more samples 55%
      vs plain verify-stop: success diff +0.002 [+0.000,+0.006], tokens 10498 vs 10182
  route[nothink->direct1200_fix2]: success 35.9% at 10163 tok | states: verified 42%, entrenched->switch 3%, unstable->more samples 55%
      vs plain verify-stop: success diff +0.001 [+0.000,+0.002], tokens 10163 vs 10182

  taxonomy table (your paper's entrenched vs unstable, now with a separate NO-COMMIT group; in the run-2 audit 9 of 11 'entrenched' problems were really 'never produced code'):
                                            problems  base_majority_ok  base_any_of_K  direct1200_any_of_K  direct1200_fix2_any_of_K  force1500_any_of_K  nothink_fix2_any_of_K
group                                                                                                                                                                          
ENTRENCHED (consistent wrong program)              5              0.00           0.20                 0.20                      0.20                0.20                   0.20
NO-COMMIT (most attempts produced no code)        18              0.06           0.06                 0.00                      0.06                0.06                   0.17
UNSTABLE (coded attempts disagree)                 3              0.67           0.67                 0.00                      0.00                0.33                   0.33
consistent+passes examples                        12              0.75           0.83                 0.67                      0.75                0.58                   0.67
  entrenched (consistent wrong program): 5, unstable: 3, no-commit: 18  -> a hypothesis to REPLICATE, not a finding, unless each group has >= 8

======== T3  FALSE-POSITIVE-AWARE K: submit an example-passing attempt or abstain; a wrong 'verified' answer costs c ========

  nothink (filter = pass the examples)
 K  success  false_positive  abstain  utility_c0  utility_c05  utility_c1
 1    0.280           0.045    0.676       0.280        0.257       0.235
 2    0.333           0.052    0.615       0.333        0.307       0.282
 3    0.360           0.061    0.579       0.360        0.330       0.300
  nothink (filter = pass the examples AND agree with the brute-force oracle)
 K  success  false_positive  abstain  utility_c0  utility_c05  utility_c1
 1    0.272           0.033    0.695       0.272        0.255       0.239
 2    0.328           0.061    0.611       0.328        0.297       0.267
 3    0.353           0.068    0.579       0.353        0.319       0.286

  direct1200 (filter = pass the examples)
 K  success  false_positive  abstain  utility_c0  utility_c05  utility_c1
 1    0.123           0.017    0.861       0.123        0.114       0.106
 2    0.161           0.034    0.805       0.161        0.144       0.127
 3    0.187           0.048    0.766       0.187        0.163       0.139
 4    0.204           0.057    0.739       0.204        0.175       0.146
 5    0.217           0.073    0.710       0.217        0.181       0.144
 6    0.229           0.087    0.684       0.229        0.185       0.141
  direct1200 (filter = pass the examples AND agree with the brute-force oracle)
 K  success  false_positive  abstain  utility_c0  utility_c05  utility_c1
 1    0.121           0.010    0.869       0.121        0.116       0.111
 2    0.156           0.017    0.827       0.156        0.147       0.139
 3    0.184           0.024    0.792       0.184        0.172       0.160
 4    0.208           0.036    0.755       0.208        0.190       0.172
 5    0.224           0.045    0.732       0.224        0.201       0.179
 6    0.237           0.053    0.711       0.237        0.211       0.184

  direct1200_fix2 (filter = pass the examples)
 K  success  false_positive  abstain  utility_c0  utility_c05  utility_c1
 1    0.237           0.091    0.672       0.237        0.192       0.146
 2    0.273           0.114    0.613       0.273        0.216       0.159
 3    0.282           0.139    0.579       0.282        0.212       0.143
  direct1200_fix2 (filter = pass the examples AND agree with the brute-force oracle)
 K  success  false_positive  abstain  utility_c0  utility_c05  utility_c1
 1    0.236           0.072    0.692       0.236        0.200       0.164
 2    0.274           0.102    0.624       0.274        0.223       0.172
 3    0.279           0.142    0.579       0.279        0.208       0.138

  force1500 (filter = pass the examples)
 K  success  false_positive  abstain  utility_c0  utility_c05  utility_c1
 1    0.201           0.078    0.721       0.201        0.161       0.122
 2    0.263           0.132    0.605       0.263        0.197       0.132
  force1500 (filter = pass the examples AND agree with the brute-force oracle)
 K  success  false_positive  abstain  utility_c0  utility_c05  utility_c1
 1    0.199           0.014    0.787       0.199        0.193       0.186
 2    0.263           0.026    0.711       0.263        0.250       0.237
  Reading: if utility at c=0.5 stops rising (or falls) with K, more samples only buy more false positives (Stroebl et al.).

======== T4  SELECTOR BAKE-OFF at the largest complete K (success; paired difference vs random with 95% CI) ========
  nothink K=3:  random: 28.3% (+0.00 [+0.00,+0.00]) | public: 35.8% (+0.08 [+0.02,+0.14]) | conf: 36.8% (+0.09 [+0.03,+0.15]) | confwin: 36.8% (+0.09 [+0.03,+0.15]) | short: 36.8% (+0.09 [+0.03,+0.15]) | cluster: 35.5% (+0.07 [+0.02,+0.14]) | bf: 35.4% (+0.07 [+0.02,+0.14]) | combo: 36.8% (+0.09 [+0.03,+0.15]) | oracle: 36.8% (+0.09 [+0.03,+0.15])
  direct1200 K=6:  random: 12.4% (+0.00 [+0.00,+0.00]) | public: 23.0% (+0.11 [+0.03,+0.20]) | conf: 23.7% (+0.11 [+0.04,+0.20]) | confwin: 23.7% (+0.11 [+0.04,+0.20]) | short: 23.7% (+0.11 [+0.04,+0.20]) | cluster: 23.7% (+0.11 [+0.04,+0.20]) | bf: 23.7% (+0.11 [+0.04,+0.20]) | combo: 23.7% (+0.11 [+0.04,+0.20]) | oracle: 23.7% (+0.11 [+0.04,+0.20])
  direct1200_fix2 K=3:  random: 24.1% (+0.00 [+0.00,+0.00]) | public: 28.2% (+0.04 [+0.01,+0.08]) | conf: 26.3% (+0.02 [-0.03,+0.07]) | confwin: 26.3% (+0.02 [-0.03,+0.07]) | short: 26.3% (+0.02 [-0.03,+0.08]) | cluster: 27.6% (+0.03 [-0.00,+0.08]) | bf: 28.0% (+0.04 [+0.01,+0.08]) | combo: 26.3% (+0.02 [-0.03,+0.08]) | oracle: 28.9% (+0.05 [+0.01,+0.10])

  within-problem AUC of each free signal for 'this attempt passes the hidden tests' (0.5 = no information; interval = bootstrap over problems):
            arm                           signal   auc    lo    hi  pairs
        nothink             passes example tests 0.929 0.750 1.000     14
        nothink      behaviour agreement among K 0.536 0.250 0.801     14
        nothink         shorter output (-tokens) 0.714 0.500 0.917     14
        nothink              mean token log-prob 0.500 0.214 0.876     14
        nothink lowest 512-token window log-prob 0.786 0.600 1.000     14
        nothink   agrees with brute-force oracle 0.786 0.000 1.000      7
     direct1200             passes example tests 0.967 0.902 1.000     46
     direct1200      behaviour agreement among K 0.696 0.352 0.934     46
     direct1200         shorter output (-tokens) 0.761 0.658 0.895     46
     direct1200              mean token log-prob 0.739 0.511 0.941     46
     direct1200 lowest 512-token window log-prob 0.717 0.643 0.828     46
     direct1200   agrees with brute-force oracle 0.924 0.785 1.000     46
direct1200_fix2             passes example tests 0.900 0.665 1.000     10
direct1200_fix2      behaviour agreement among K 0.750 0.438 1.000     10
direct1200_fix2         shorter output (-tokens) 0.800 0.333 1.000     10
direct1200_fix2              mean token log-prob 0.200 0.000 0.667     10
direct1200_fix2 lowest 512-token window log-prob 0.100 0.000 0.313     10
direct1200_fix2   agrees with brute-force oracle 0.900 0.663 1.000     10
      force1500             passes example tests 1.000 1.000 1.000      5
      force1500      behaviour agreement among K 0.500 0.500 0.500      5
      force1500         shorter output (-tokens) 0.600 0.000 1.000      5
      force1500              mean token log-prob 0.600 0.000 1.000      5
      force1500 lowest 512-token window log-prob 0.800 0.333 1.000      5
      force1500   agrees with brute-force oracle 0.900 0.622 1.000      5
  -> rows with fewer than 40 solved-vs-failed pairs are INCONCLUSIVE (most problems are all-pass or all-fail, so few pairs exist).

======== T5  BRUTE-FORCE ORACLE (differential testing against a slow, simple solution) ========
  problems with a trusted brute-force (passes the examples): 28/38
  attempts passing the examples: 148 | false positives (fail hidden): 33 -> caught by the oracle: 13 | correct attempts wrongly rejected: 3/115 | no usable comparison: 12

======== T6  ONLINE ABORT (DeepConf-style): cut an attempt when its rolling confidence drops, or when it gets too long ========
  114 single-generation attempts | tokens in failed attempts: 89% of all tokens | attempts over 4000 tokens: 65 (pass rate 5%)
  policy                              tokens saved  successes kept
  length cap 1500                             67%             69%
  length cap 2500                             50%             81%
  length cap 4000                             27%             91%
  abort below p5  window log-prob  -0.37             4%            100%
  abort below p15 window log-prob  -0.35            16%             91%
  abort below p30 window log-prob  -0.32            31%             84%
  within-problem AUC: lowest-window confidence 0.79 vs shortness 0.71

======== T7  PLAN DIVERSITY (PlanSearch-lite) vs independent samples, same K ========
  NOT RUN (needs arms 'plan' and 'nothink' with K>=2)

======== T8  REPAIR FEEDBACK LADDER at matched tokens ========
  nothink_fix2 : success 34.2% | tokens 8326 | rounds 2.21 | vs resample K=2+example filter: +0.006 [-0.125,+0.136]
  direct1200_fix2: success 23.8% | tokens 2764 | rounds 2.61
  direct1200_fix2 single  minus  nothink_fix2 single: -0.104  CI [-0.203, -0.008]  -> CI excludes 0

======== T9  EFFORT LADDER on the hard problems (the plain arm solves them half the time or less) ========
  hard problems: 16 of 38
            arm  problems  pass1  any_of_K  avg_tokens  forced  cut_no_code
     direct1200        16  0.010     0.062    1142.896   0.000        0.000
    direct_many        16  0.020     0.062    1137.141   0.000        0.000
        nothink        16  0.062     0.188    4523.104   0.000        0.562
      force1500        16  0.031     0.062    2180.344   0.781        0.000
   nothink_fix2        16  0.125     0.125   10211.500   0.000        0.312
direct1200_fix2        16  0.062     0.062    3302.146   0.000        0.000
        think3k        16  0.125     0.125    7793.312   1.000        0.500
        think8k        16  0.188     0.188   12382.000   1.000        0.375
  solved by at least one arm (oracle routing): 5/16
  coverage of direct_many on the hard problems (share with >=1 correct among K attempts): K=1: 2% | K=2: 4% | K=4: 5% | K=8: 6% | K=16: 6%   (still rising at the largest K = sampling helps; flat = capability limit)
  coverage of think3k on the hard problems (share with >=1 correct among K attempts): K=1: 12%   (still rising at the largest K = sampling helps; flat = capability limit)
  coverage of think8k on the hard problems (share with >=1 correct among K attempts): K=1: 19%   (still rising at the largest K = sampling helps; flat = capability limit)

======== T10  HARNESS SCAFFOLDS (prompt-level) at the same K ========
  NOT RUN (add scaf_* arms with K_PER_ARM.update(EXTRAS))

======== T11  TOOL LOOP: the model tests its own code on its own inputs ========
  NOT RUN (add 'toolloop' with K_PER_ARM.update(EXTRAS))

======== T12  LATENCY: tokens vs modeled wall-clock (single-stream speed 16 tok/s) ========
  nothink single                               tokens    3912 | modeled latency    243s | success 28.1%
  nothink K=3 public                           tokens   11740 | modeled latency    296s | success 35.8%
  nothink verify-stop K<=3 w=1                 tokens   10182 | modeled latency    632s | success 35.9%
  nothink verify-stop K<=3 w=2                 tokens   10907 | modeled latency    473s | success 36.0%
  nothink verify-stop K<=3 w=3                 tokens   11740 | modeled latency    296s | success 36.0%
  nothink_fix2 single                          tokens    8326 | modeled latency    516s | success 34.2%
  Reading: sequential verify-stop saves tokens but adds wall-clock; waves of 2-3 recover most of the speed. Which to use depends on whether tokens or seconds are the budget.

======== T13  REPLICATION (random half-splits of the problems) and CONTAMINATION (older vs newer problems) ========
  'verify-stop saves >=20% tokens': full-sample answer = False | same answer on 92% of random half-splits (N=19 each)
  'public filter beats random@K': full-sample answer = True | same answer on 100% of random half-splits (N=19 each)
  'repair beats plain single': full-sample answer = True | same answer on 82% of random half-splits (N=19 each)
  contamination check (nothink pass@1): problems before 2025-02-22: 19.3% (n=17) vs on/after: 35.3% (n=21); a much higher old-problem rate would hint at training-data leakage (dates span 2025-01-11..2025-04-06)

======== TEST STATUS (pre-registered rules) ========
  T1   verify-then-stop         DEAD (saving <20%): token saving +13%, success diff +0.001 [+0.000,+0.002]
  T2   consistency routing      nothink_fix2: success diff +0.002 [+0.000,+0.006] (entrenched share 3%; needs >= 8 entrenched problems to mean anything)
  T3   false-positive-aware K   table above (utility at c=0.5 vs K)
  T4   selector bake-off        AUC and paired tables above
  T5   brute-force oracle       WEAK (catches under half of the false positives): caught 13/33 false positives, wrongly rejected 3% of correct attempts
  T6   online abort             CONFIDENCE BEATS LENGTH: AUC 0.79 vs 0.71
  T7   plan diversity           NOT RUN (see its section)
  T8   repair feedback ladder   repair(full feedback) - matched resampling: +0.006 [-0.125,+0.136]
  T9   effort ladder            table above
  T10  harness scaffolds        NOT RUN (see its section)
  T11  tool loop                NOT RUN (see its section)
  T12  latency                  table above
  T13  replication              stability of each answer across half-splits printed above (low % = do not trust it)

  Remember: N is small. Treat every line as a direction to replicate, not a proven result.

======== T14  FINISH-TIME DISTRIBUTION and the best RESTART CAP (cap chosen on one half of the problems, scored on the other half; 40 random splits) ========

  nothink: 114 attempts | finished within 1000 tokens: 23% (pass 69%) | over 4000 tokens: 57% (pass 5%) | tokens per success uncapped: 13942
      cap  tokens/success  successes kept  tokens saved/attempt
      300             inf              0%                   92%
      500            7009             25%                   87%
      700            6371             38%                   83%
     1000            5800             56%                   77%
     1500            6645             69%                   67%
     2000            8051             72%                   58%
     3000            9526             84%                   42%
     4000           11173             91%                   27%
     6000           13942            100%                    0%
    held-out: median cap chosen on the dev half = 1000 | tokens per success on the test half -55% vs uncapped | successes kept 46% (median over splits)

  direct1200: 228 attempts | finished within 1000 tokens: 22% (pass 56%) | over 4000 tokens: 0% (pass nan%) | tokens per success uncapped: 8414
      cap  tokens/success  successes kept  tokens saved/attempt
      300            6022             39%                   72%
      500            5644             68%                   54%
      700            6628             79%                   38%
     1000            7151            100%                   15%
     1500            8414            100%                    0%
     2000            8414            100%                    0%
     3000            8414            100%                    0%
     4000            8414            100%                    0%
     6000            8414            100%                    0%
    held-out: median cap chosen on the dev half = 500 | tokens per success on the test half -17% vs uncapped | successes kept 60% (median over splits)

  force1500: 76 attempts | finished within 1000 tokens: 25% (pass 58%) | over 4000 tokens: 0% (pass nan%) | tokens per success uncapped: 9999
      cap  tokens/success  successes kept  tokens saved/attempt
      300           22732              7%                   85%
      500            9286             27%                   75%
      700            8474             40%                   66%
     1000            6308             73%                   54%
     1500            6877             93%                   36%
     2000            8656             93%                   19%
     3000            9999            100%                    0%
     4000            9999            100%                    0%
     6000            9999            100%                    0%
    held-out: median cap chosen on the dev half = 1000 | tokens per success on the test half -30% vs uncapped | successes kept 68% (median over splits)
  Reading: tokens per success has a minimum at some cap if finish times are a fast mode plus a heavy tail (restart theory: Luby et al.; Gomes & Selman). The held-out line is the honest number.

======== T15  COMMITMENT ABORT: stop an attempt that has not opened a code fence by token N (compared with a plain length cap at N) ========
      N |  commit-abort: tokens/success   kept |  length-cap: tokens/success   kept
    300 |                          3811    31% |                       34200     0%
    500 |                          3609    62% |                        7009    25%
    700 |                          4334    69% |                        6371    38%
   1000 |                          5619    69% |                        5800    56%
   1500 |                          6323    81% |                        6645    69%
  no abort: 13942 tokens/success
  predicting 'this attempt will be cut off' (within-problem AUC): no code fence by token 700: 0.73 (30 pairs) | hesitation words per 1000 (first 3000 chars): 0.60 (30 pairs)  [diagnostic only: this was 0.91 in run 1 and 0.36 in run 2, i.e. it did NOT replicate]
  pooled: cut-off rate when no fence by token 700: 75% vs 3% when a fence appeared
  among FINISHED attempts only, does an earlier fence predict a correct answer? within-problem AUC 0.33  (about 0.5 = no: finishing gates the attempt, the tests decide correctness)
  held-out commit-abort: median N chosen on the dev half = 1500 | tokens per success on the test half -46% vs no abort | successes kept 68% (median over 40 splits)

======== T16  TRIAGE vs the NO-TRIAGE FRONTIER: success at EQUAL tokens (gap = triage success minus what plain verify-stop reaches at the same tokens) ========
  direct1200: no-triage verify-stop curve: K=1: 12.0%@1036 | K=2: 16.6%@1982 | K=3: 18.1%@2888 | K=4: 20.4%@3759 | K=5: 21.7%@4585 | K=6: 23.0%@5403
    give up after 1 cut-off(s), K<=6: success 15.1% at 1142 tokens | gap vs the no-triage frontier +2.7% [+0.6%,+5.1%]
    give up after 2 cut-off(s), K<=6: success 19.5% at 2148 tokens | gap vs the no-triage frontier +2.6% [-0.3%,+6.9%]
  nothink: no-triage verify-stop curve: K=1: 28.2%@3900 | K=2: 33.4%@7152 | K=3: 35.8%@10206
    give up after 1 cut-off(s), K<=3: success 31.7% at 4819 tokens | gap vs the no-triage frontier +1.9% [-0.6%,+6.0%]
    give up after 2 cut-off(s), K<=3: success 34.9% at 8164 tokens | gap vs the no-triage frontier +0.8% [-0.9%,+2.9%]
  force1500: no-triage verify-stop curve: K=1: 20.2%@1973 | K=2: 26.3%@3584
    give up after 1 cut-off(s), K<=2: success 23.7% at 2373 tokens | gap vs the no-triage frontier +2.0% [-1.0%,+5.4%]
    give up after 2 cut-off(s), K<=2: success 26.3% at 3601 tokens | gap vs the no-triage frontier +0.0% [+0.0%,+0.0%]

======== T16b  ATTEMPT-LEVEL ABORT (length cap / no code fence by token N) vs the same frontier — pre-registered expectation: it slides ALONG the frontier, it does not shift it ========
  cap-abort@2500: success 30.8% at 5151 tokens | gap vs the no-abort frontier +0.5% [-6.2%,+6.8%]
  commit-abort@700: success 25.0% at 2178 tokens | gap vs the no-abort frontier +9.4% [+0.3%,+18.4%]

======== T17  FINISH-AWARE CASCADES (cheap attempts with triage, then escalate to repair only if no attempt passes the examples) ========
  baseline (simple best-of-N): plain x3 + example filter: success 35.8% [21.1%,50.0%] at 11740 tokens/problem, modeled latency 296s
  C1 direct1200 (triage g=1) -> nothink_fix2: success 33.8% [20.2%,47.9%] at 9178 tokens, modeled latency 569s | vs plain best-of-3: -0.021 [-0.158,+0.111] at 78% of the tokens
  C2 direct1200 (triage g=1) -> direct1200_fix2: success 24.7% [12.6%,37.1%] at 3733 tokens, modeled latency 232s | vs plain best-of-3: -0.112 [-0.231,-0.017] at 32% of the tokens
  C3 direct1200 (triage g=2) -> direct1200_fix2 -> nothink_fix2: success 35.1% [21.7%,49.0%] at 11668 tokens, modeled latency 724s | vs plain best-of-3: -0.007 [-0.140,+0.122] at 99% of the tokens
  C4 force1500 (triage g=1) -> nothink_fix2: success 35.6% [21.1%,51.4%] at 9273 tokens, modeled latency 575s | vs plain best-of-3: -0.002 [-0.134,+0.135] at 79% of the tokens
  C5 nothink (triage g=1) -> nothink_fix2: success 42.1% [27.2%,57.9%] at 11705 tokens, modeled latency 726s | vs plain best-of-3: +0.063 [-0.018,+0.164] at 100% of the tokens
  C0 nothink x3 no triage -> nothink_fix2 (control): success 43.9% [28.9%,58.1%] at 16901 tokens, modeled latency 1048s | vs plain best-of-3: +0.081 [+0.002,+0.184] at 144% of the tokens

======== T18  FRONTIER MEMBERSHIP: how often is each strategy Pareto-optimal when the problems are resampled? (300 bootstrap resamples) ========
                                         strategy  success    tokens  frontier_prob
                                direct1200 single    0.122  1031.098          1.000
                       direct1200 triage g=1 K<=6    0.151  1141.604          0.997
                    nothink commit-abort@700 K<=3    0.250  2177.960          0.833
          C5 nothink (triage g=1) -> nothink_fix2    0.421 11705.492          0.813
C0 nothink x3 no triage -> nothink_fix2 (control)    0.439 16901.327          0.783
                                 force1500 single    0.195  1960.506          0.767
                          nothink triage g=1 K<=3    0.317  4819.446          0.750
                        force1500 triage g=1 K<=2    0.237  2372.698          0.470
                                   nothink single    0.281  3912.338          0.463
                          nothink triage g=2 K<=3    0.349  8163.707          0.413
                              nothink_fix2 single    0.342  8325.684          0.377
                  route[nothink->direct1200_fix2]    0.359 10162.657          0.367
                   force1500 verify-stop K<=2 w=1    0.263  3581.990          0.367
                              nothink K=2 confwin    0.341  7813.755          0.343
  point-estimate frontier has 15 strategies; 7 of them are on the frontier in at least half of the resamples

======== T24  WHERE DOES THE UNCERTAINTY COME FROM? (attempt sampling vs which problems are in the sample) ========
  nothink          pass@1 28.1% | SE from attempt sampling alone 0.018 | SE from which problems are sampled 0.068 (x4)
  direct1200       pass@1 12.3% | SE from attempt sampling alone 0.012 | SE from which problems are sampled 0.045 (x4)
  direct1200_fix2  pass@1 23.7% | SE from attempt sampling alone 0.016 | SE from which problems are sampled 0.065 (x4)
  force1500        pass@1 19.7% | SE from attempt sampling alone 0.022 | SE from which problems are sampled 0.057 (x3)
  Reading: if the problem-sampling SE dominates, more attempts per problem barely narrow the intervals; more problems do. That is why this run uses 50 problems and few attempts.

======== T19  RELIABILITY (does the same problem succeed every time?) and SUCCESS BY DIFFICULTY LABEL ========
            arm  K  pass_at_1  pass_at_K  pass_all_K  all_or_nothing
        nothink  3      0.281      0.368       0.184           0.816
     direct1200  6      0.123      0.237       0.053           0.816
direct1200_fix2  3      0.237      0.289       0.158           0.868
      force1500  2      0.197      0.263       0.132           0.868
                 easy  medium  hard n_easy/med/hard
nothink           NaN    0.93  0.18          0/5/33
direct1200        NaN    0.53  0.06          0/5/33
direct1200_fix2   NaN    0.73  0.16          0/5/33
force1500         NaN    1.00  0.08          0/5/33
nothink_fix2      NaN    1.00  0.24          0/5/33

======== T20  FALSE POSITIVES: consistent-wrong vs dispersed-wrong, and do repaired answers overfit the examples? ========
     pid  passers  wrong  behaviours             kind
abc396_e        7      7           3  dispersed-wrong
arc194_d        4      4           1 consistent-wrong
arc194_e        4      4           2 consistent-wrong
arc195_b        3      3           2 consistent-wrong
abc392_f        3      2           2            mixed
arc192_b        2      2           2 consistent-wrong
abc390_e        2      2           1 consistent-wrong
abc398_d        3      2           2            mixed
abc393_e       11      2           3            mixed
abc398_g        2      2           2 consistent-wrong
abc394_d       13      1           2            mixed
abc392_g        1      1           1 consistent-wrong
  problems by class: {'mixed': 4, 'dispersed-wrong': 1, 'consistent-wrong': 8}  (disagreement between candidates can only catch dispersed-wrong; consistent-wrong needs an outside oracle)
  repair arms: first-try example-passers that fail hidden tests 5/29 (17%) vs repaired-into-passing 13/29 (45%), Fisher exact p = 0.05

======== T21  VERIFICATION OVERHEAD and PRICE-RATIO SENSITIVITY (cost = output tokens + r x input tokens) ========
  per problem: model-written test inputs 242 tokens | brute-force oracle 4389 tokens | one plain attempt 3914 tokens | test execution 3.3 CPU-seconds per attempt (CPU, not GPU)
            arm  out_tok  in_tok  tok/success r=0  tok/success r=0.1  tok/success r=0.25
        nothink   3914.0   768.0          13942.0            14215.0             14625.0
     direct1200   1033.0   771.0           8414.0             9042.0              9983.0
direct1200_fix2   2761.0  4900.0          11656.0            13725.0             16829.0
      force1500   1973.0  2363.0           9999.0            11196.0             12992.0
   nothink_fix2   8326.0 10513.0          24337.0            27410.0             32020.0
  Reading: repair re-reads long prompts (input tokens), so it looks cheaper than it is when only output tokens are counted; the ranking matters only if rows reorder as r grows.

======== T22  CONTAMINATION PROBE (can the model continue a statement it should not know?) ========
  NOT RUN (no probe scores)

======== T25  ORACLE AS A FILTER on repair attempts (accept only example-passers that agree with the brute-force oracle where it can be checked) ========
            arm  passers  fp_rate  passers_agreeing_with_oracle  fp_rate_after_filter  correct_kept
direct1200_fix2       37    0.270                            35                 0.229         1.000
   nothink_fix2       21    0.381                            17                 0.294         0.923

======== T23  WHICH STRATEGY UNDER A FIXED BUDGET? (best deployable strategy at or under each tokens-per-problem budget; paired CI vs plain best-of-N) ========
  <=    500 tokens: no strategy fits
  <=   1000 tokens: no strategy fits
  <=   2000 tokens: force1500 single                                     19.5% [9.0%,31.5%] at 1961 tok, modeled latency 122s | vs plain best-of-3: -0.163 [-0.285,-0.056]
  <=   4000 tokens: nothink single                                       28.1% [16.4%,42.2%] at 3912 tok, modeled latency 243s | vs plain best-of-3: -0.077 [-0.146,-0.025]
  <=   8000 tokens: nothink K=2 conf                                     34.2% [20.1%,49.1%] at 7841 tok, modeled latency 283s | vs plain best-of-3: -0.017 [-0.053,+0.021]
  <=  16000 tokens: C5 nothink (triage g=1) -> nothink_fix2              42.1% [27.2%,57.9%] at 11705 tok, modeled latency 726s | vs plain best-of-3: +0.063 [-0.025,+0.160]
  latency <=  120s: direct1200 K=6 conf                                  23.7% at 6200 tokens
  latency <=  300s: nothink K=3 conf                                     36.8% at 11740 tokens
  latency <=  600s: nothink K=3 conf                                     36.8% at 11740 tokens

======== HYPOTHESIS STATUS (pre-registered rules; N is small, so read as direction) ========
  H1   PRIMARY: triage (give up after g=2 cut-offs) is above the no-triage frontier at equal tokens NOT SHOWN: triage g=2 on direct1200 (K<=6) is +2.6% [-0.3%,+6.9%] above the no-triage frontier at equal tokens (rule: gap >= +3 points and CI lower > 0)
  H1b  finish-aware cascade C1 is on the Pareto frontier in >=50% of resamples NOT SHOWN: cascade C1 is on the Pareto frontier in 0% of the bootstrap resamples (rule: >= 50%); most frequent cascade: C5 nothink (triage g=1) -> nothink_fix2 (81%)
  H2   attempt-level length cap shifts the frontier (expected: no)    NO SHIFT (moves along the frontier): cap-abort@2500 gap +0.5% [-6.2%,+6.8%]
  H2b  no-fence-by-700 abort shifts the frontier (expected: no)       SHIFTS the frontier: commit-abort@700 gap +9.4% [+0.3%,+18.4%]
  H3   cheap capped repair is more token-efficient than plain repair  NOT SHOWN: tokens per success 11608 vs 24337 (48%), success diff -0.104 [-0.208,-0.007] (rule: <=60% tokens/success and diff >= -5pp)
  H4   budget forcing rescues rambling attempts                       NOT SHOWN: success diff -0.086 [-0.179,-0.007] at 50% of the tokens
  H5   run-1/2 findings replicate (filter > random; repair > matched resampling) NOT REPLICATED: example filter vs random +0.076 [+0.022,+0.138]; repair vs matched resampling +0.006 [-0.126,+0.129]
  H6   capped direct matches plain at <=40% tokens                    NOT SHOWN: direct1200 vs plain success diff -0.159 [-0.252,-0.076] at 26% of the tokens (rule: >= -3pp at <=40% tokens)
  H7   coverage on hard problems: sampling vs capability              FLAT (capability limit): coverage 6% at K=8 -> 6% at K=16; 15 of 16 hard problems never solved in 16 cheap attempts (95% upper bound on their per-attempt pass rate about 17%)
  H8   thinking (8k) solves problems nothing else solves              NOT SHOWN: think8k solved 1 of the 12 hard problems that no non-thinking arm solved (rule: >= 15%)
  H8b  thinking (3k) solves problems nothing else solves              NOT SHOWN: think3k solved 0 of the 12 hard problems that no non-thinking arm solved (rule: >= 15%)
  H9   repair overfits the examples                                   SUPPORTED: repaired FP rate 45% vs first-try 17%, Fisher exact p = 0.05 (rule: >10 points higher)
  H10  brute-force repair reduces false positives                     NOT RUN (arm or data missing)
  H11  oracle filter cuts false positives of repair attempts          NOT SHOWN: direct1200_fix2 false-positive rate 27% -> 23% keeping 100% of its correct answers (rule: >= 5 points lower, >= 90% kept)
```
